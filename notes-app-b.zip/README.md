To start server in the developement mode -> npm run dev
